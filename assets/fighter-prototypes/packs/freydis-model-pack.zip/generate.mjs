import * as T from 'three';
import { GLTFExporter } from 'three/addons/exporters/GLTFExporter.js';
import fs from 'node:fs/promises';

// Node-only adapter for the Three.js exporter. Install `three` to regenerate.
globalThis.FileReader = class {
  readAsArrayBuffer(blob) { blob.arrayBuffer().then(data => { this.result=data; this.onloadend?.(); }); }
  readAsDataURL(blob) { blob.arrayBuffer().then(data => { this.result=`data:${blob.type};base64,${Buffer.from(data).toString('base64')}`; this.onloadend?.(); }); }
};
const mats={};
for(const [name,color,metalness,roughness] of [
  ['bronze','#c98f3a',.65,.48],['goldEdge','#e2b45c',.65,.4],
  ['darkBronze','#785226',.6,.6],['crimson','#9e2b2b',0,.95],
  ['redHighlight','#c74848',0,.95],['leather','#493124',0,.94],
  ['skin','#c89b79',0,.85],['ivory','#e6e2d8',0,.9],
  ['iron','#c2c9d1',.7,.35],['wood','#8a6238',0,.9],['shadow','#191713',0,1],
]) mats[name]=new T.MeshStandardMaterial({name,color,metalness,roughness,flatShading:true});
function group(name,parent,x=0,y=0,z=0){const g=new T.Group();g.name=name;g.position.set(x,y,z);parent?.add(g);return g;}
function mesh(name,geo,mat,parent,x=0,y=0,z=0){const m=new T.Mesh(geo,mats[mat]);m.name=name;m.position.set(x,y,z);parent.add(m);return m;}
function box(name,w,h,d,mat,p,x=0,y=0,z=0){return mesh(name,new T.BoxGeometry(w,h,d),mat,p,x,y,z);}
function poly(name,points,depth,mat,p,x=0,y=0,z=0,bevel=0){
  const s=new T.Shape();points.forEach(([a,b],i)=>i?s.lineTo(a,b):s.moveTo(a,b));s.closePath();
  return mesh(name,new T.ExtrudeGeometry(s,{depth,bevelEnabled:bevel>0,bevelThickness:bevel,bevelSize:bevel,bevelSegments:1,steps:1}),mat,p,x,y,z);
}
function cyl(name,r1,r2,h,mat,p,x=0,y=0,z=0,n=10){return mesh(name,new T.CylinderGeometry(r1,r2,h,n),mat,p,x,y,z);}
function beam(name,a,b,width,depth,mat,p){const start=new T.Vector3(...a),end=new T.Vector3(...b),m=box(name,width,start.distanceTo(end),depth,mat,p);m.position.copy(start.add(end).multiplyScalar(.5));m.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),new T.Vector3(...b).sub(new T.Vector3(...a)).normalize());return m;}

function baseBody(){
 const root=group('Dienekes_Body'); root.userData={prototype:true,forward:'+Z',up:'+Y',rig:'Rigid named pivots; no skin weights or clips'};
 const pelvis=group('Pelvis',root,0,1.04,0);
 box('Tunic',.53,.43,.3,'ivory',pelvis,0,-.03,0);
 const torso=group('Torso',pelvis,0,.21,0);
 poly('Cuirass',[[ -.27,-.2],[.27,-.2],[.34,.29],[.25,.47],[-.25,.47],[-.34,.29]],.32,'bronze',torso,0,0,-.16,.025);
 for(const s of [-1,1]){
  poly('ChestPlate'+s,[[-.12,-.06],[.1,-.06],[.14,.06],[.1,.16],[-.1,.15]],.035,'goldEdge',torso,s*.15,.2,.18,.008);
  box('ShoulderStrap'+s,.115,.16,.39,'darkBronze',torso,s*.24,.44,0);
  cyl('Clasp'+s,.043,.043,.045,'goldEdge',torso,s*.24,.4,.23).rotation.x=Math.PI/2;
 }
 box('Belt',.58,.09,.37,'leather',torso,0,-.18,0);
 box('BeltBuckle',.11,.09,.03,'goldEdge',torso,0,-.18,.2);
 for(let i=0;i<3;i++)box('ArmorSeam'+i,.4-i*.035,.012,.015,'darkBronze',torso,0,.13-i*.085,.197);
 for(let i=-2;i<=2;i++)poly('FrontPteruges'+i,[[-.045,.02],[.045,.02],[.04,-.26],[-.036,-.28]],.035,i%2?'leather':'darkBronze',pelvis,i*.11,-.08,.19,.004);
 for(const s of [-1,1]){
  const thigh=group(s<0?'Hip_L':'Hip_R',pelvis,s*.18,-.15,0);
  cyl('Thigh'+s,.11,.095,.38,'skin',thigh,0,-.19,0,8);
  const shin=group(s<0?'Knee_L':'Knee_R',thigh,0,-.39,0);
  cyl('Shin'+s,.092,.065,.35,'skin',shin,0,-.175,0,8);
  poly('Greave'+s,[[-.085,0],[.085,0],[.07,-.34],[-.065,-.34]],.09,'bronze',shin,0,-.01,.02,.013);
  box('GreaveRidge'+s,.023,.29,.02,'goldEdge',shin,0,-.17,.13);
  box('Sandal'+s,.18,.075,.29,'leather',shin,0,-.435,.055);
  box('Foot'+s,.155,.065,.21,'skin',shin,0,-.39,.06);
  box('SandalStrap'+s,.18,.045,.07,'leather',shin,0,-.365,.09);
  const arm=group(s<0?'Shoulder_L':'Shoulder_R',torso,s*.37,.34,0);
  arm.rotation.z=s*.13;
  cyl('UpperArm'+s,.092,.083,.32,'skin',arm,0,-.16,0,8);
  const forearm=group(s<0?'Elbow_L':'Elbow_R',arm,0,-.33,0);
  cyl('Forearm'+s,.085,.06,.28,'skin',forearm,0,-.14,0,8);
  cyl('Bracer'+s,.09,.072,.17,'leather',forearm,0,-.15,0,8);
  box('BracerTrim'+s,.16,.025,.16,'bronze',forearm,0,-.22,0);
  box('Hand'+s,.115,.14,.13,'skin',forearm,0,-.33,0);
  group(s<0?'ShieldSocket':'SpearSocket',forearm,0,-.31,s<0?.25:.075);
 }
 const head=group('Head',torso,0,.64,0);
 cyl('Neck',.075,.08,.12,'skin',torso,0,.52,0);
 box('Face',.25,.29,.23,'skin',head,0,.01,.01);
 mesh('HelmetCrown',new T.SphereGeometry(.205,10,5,0,Math.PI*2,0,Math.PI/2),'bronze',head,0,.135,0);
 box('HelmetBack',.31,.2,.065,'bronze',head,0,.035,-.135);
 box('EyeRecess',.285,.073,.025,'shadow',head,0,.06,.138);
 box('Brow',.34,.045,.045,'goldEdge',head,0,.108,.14);
 poly('Nasal',[[-.025,.1],[.025,.1],[.017,-.13],[-.018,-.13]],.045,'bronze',head,0,0,.16);
 for(const s of [-1,1])poly('CheekGuard'+s,[[-.06,.025],[.06,.025],[.05,-.2],[-.055,-.16]],.065,'bronze',head,s*.119,-.005,.1,.009);
 box('CrestRail',.45,.055,.08,'darkBronze',head,0,.31,0);
 poly('TransverseCrest',[[-.29,0],[-.265,.125],[-.14,.21],[.14,.21],[.265,.125],[.29,0]],.075,'crimson',head,0,.33,-.035);
 for(let i=-5;i<=5;i++)box('CrestTuft'+i,.018,.085,.081,'redHighlight',head,i*.045,.39+.065*(1-Math.abs(i)/6),0);
 // Folded cape, modeled as a shallow solid with faceted alternating pleats.
 const cape=group('Cape',torso,0,.38,-.23);
 for(let i=0;i<6;i++){
  const x0=-.29+i*.096,x1=x0+.096;
  poly('CapeFold'+i,[[x0,0],[x1,0],[x1*1.38,-.95+(i%2)*.04],[x0*1.38,-.95]],.028,i%2?'crimson':'redHighlight',cape,0,0,-.035*(i%2));
 }
 return root;
}
mats.fur=new T.MeshStandardMaterial({color:'#8d7f6a',roughness:1,flatShading:true});
mats.hair=new T.MeshStandardMaterial({color:'#a8763c',roughness:1,flatShading:true});
mats.mail=new T.MeshStandardMaterial({color:'#6f7681',metalness:.5,roughness:.7,flatShading:true});
export function makeBody(){
 const r=baseBody();r.name='Freydis_Body';
 const remove=[];r.traverse(o=>{if(/^(Cuirass|ChestPlate|ShoulderStrap|Clasp|ArmorSeam|FrontPteruges|Crest|Transverse|Cape|Greave|CheekGuard|EyeRecess)/.test(o.name))remove.push(o)});remove.forEach(o=>o.removeFromParent());
 r.traverse(o=>{if(!o.isMesh)return;if(/^(Helmet|Brow|Nasal|BracerTrim)/.test(o.name))o.material=mats.iron;if(/^(Thigh|Shin)/.test(o.name))o.material=mats.leather;if(/^(Foot|Sandal)/.test(o.name))o.material=mats.leather;});
 r.getObjectByName('Tunic').material=mats.leather;
 const t=r.getObjectByName('Torso'),h=r.getObjectByName('Head');
 box('MailCoat',.58,.59,.34,'mail',t,0,.12,0);
 for(let i=0;i<7;i++)box('MailRow'+i,.55,.018,.015,'iron',t,0,.36-i*.075,.18);
 for(const s of [-1,1]){
  box('Eye'+s,.035,.025,.014,'shadow',h,s*.062,.048,.132);
  for(let i=0;i<4;i++){
   const tuft=mesh('FurCollar'+s+i,new T.IcosahedronGeometry(.12,0),'fur',t,s*(.12+i*.085),.4-i*.025,0);tuft.scale.set(1,1,1.7);
  }
  for(let i=0;i<6;i++){mesh('Braid'+s+i,new T.IcosahedronGeometry(.058-i*.003,0),'hair',h,s*(.15+.014*Math.sin(i)), -.055-i*.073,-.005);}
  cyl('BraidTie'+s,.036,.036,.035,'leather',h,s*.15,-.44,0,6);
  const horn=poly('Horn'+s,[[0,0],[s*.10,.02],[s*.22,.18],[s*.25,.30],[s*.16,.17],[s*.06,.12]],.055,'ivory',h,s*.18,.18,-.025);
  const knee=r.getObjectByName(s<0?'Knee_L':'Knee_R');
  cyl('Boot'+s,.105,.085,.23,'leather',knee,0,-.31,0,8);
  for(let i=0;i<3;i++)cyl('BootWrap'+s+i,.11,.10,.027,'fur',knee,0,-.23-i*.06,0,8);
 }
 box('HelmetBand',.035,.055,.38,'iron',h,0,.25,0);
 r.getObjectByName('SpearSocket').name='AxeSocket';
 return r;
}
export function makeShield(){
 const r=group('Freydis_Buckler');r.userData={attachment:'ShieldSocket',forward:'+Z',origin:'rear grip'};
 const disc=cyl('WoodShield',.34,.34,.055,'wood',r,0,0,0,24);disc.rotation.x=Math.PI/2;
 mesh('IronRim',new T.TorusGeometry(.33,.018,6,24),'iron',r,0,0,.026);
 for(const s of [-1,1])poly('Paint'+s,[[0,0],[s*.28,.095],[s*.30,-.09]],.005,'crimson',r,0,0,.03);
 for(const x of [-.21,-.105,0,.105,.21]){const len=2*Math.sqrt(.31**2-x*x);box('PlankSeam',.006,len,.005,'leather',r,x,0,.037);}
 mesh('Boss',new T.SphereGeometry(.092,10,6),'iron',r,0,0,.05).scale.z=.65;
 box('RearGrip',.18,.04,.055,'leather',r,0,0,-.06);return r;
}
export function makeAxe(){
 const r=group('Freydis_Axe');r.userData={attachment:'AxeSocket',axis:'+Y',origin:'grip center',use:'stylized game prop'};
 cyl('Haft',.025,.023,.75,'wood',r,0,.15,0,8);
 cyl('Grip',.03,.03,.20,'leather',r,0,0,0,8);
 for(let i=0;i<5;i++)cyl('GripWrap',.032,.032,.015,'darkBronze',r,0,-.08+i*.04,0,8);
 box('Eye',.10,.10,.085,'mail',r,0,.46,0);
 poly('BeardedBlade',[[.025,.04],[.15,.10],[.26,.11],[.28,.03],[.27,-.11],[.22,-.22],[.12,-.21],[.09,-.14],[.13,-.07],[.025,-.045]],.035,'iron',r,0,.46,-.0175);
 poly('BladeEdge',[[.24,.10],[.26,.11],[.28,.03],[.27,-.11],[.22,-.22],[.19,-.20],[.24,-.10],[.25,.02]],.039,'ivory',r,0,.46,-.0195);return r;
}
const assembled=makeBody();assembled.name='Freydis_Assembled';
assembled.getObjectByName('ShieldSocket').add(makeShield());assembled.getObjectByName('AxeSocket').add(makeAxe());
const exporter=new GLTFExporter();
for(const [n,o] of [['body',makeBody()],['shield',makeShield()],['axe',makeAxe()],['assembled',assembled]])await fs.writeFile('freydis-'+n+'.glb',Buffer.from(await exporter.parseAsync(o,{binary:true})));
const faces=[];assembled.updateMatrixWorld(true);assembled.traverse(o=>{if(!o.isMesh)return;const g=o.geometry.index?o.geometry.toNonIndexed():o.geometry,p=g.attributes.position;for(let i=0;i<p.count;i+=3)faces.push({vertices:[0,1,2].map(j=>new T.Vector3().fromBufferAttribute(p,i+j).applyMatrix4(o.matrixWorld).toArray()),color:o.material.color.clone().convertLinearToSRGB().toArray()});});
await fs.writeFile('mesh-preview.json',JSON.stringify(faces));console.log(faces.length+' triangles');
