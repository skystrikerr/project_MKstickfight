Freydis Eiriksdottir - third roster fighter (viking)
Low-poly prototype matching current game equipment: horned helm, braid, fur collar, mail coat, round buckler and one-handed bearded axe. Stylized game design, not a historical reconstruction.
Separate body, shield, axe, and assembled GLBs. 2,402 triangles assembled.
Rigid named pivots: +Y up, +Z forward. ShieldSocket and AxeSocket. No skin weights or animation clips. Not integrated into the game.
Regenerate with node generate.mjs after installing three. Source and actual geometry preview included.
