import * as T from 'three';
import { GLTFExporter } from 'three/addons/exporters/GLTFExporter.js';
import fs from 'node:fs/promises';

// Node-only adapter for the Three.js exporter. Install `three` to regenerate.
globalThis.FileReader = class {
  readAsArrayBuffer(blob) { blob.arrayBuffer().then(data => { this.result=data; this.onloadend?.(); }); }
  readAsDataURL(blob) { blob.arrayBuffer().then(data => { this.result=`data:${blob.type};base64,${Buffer.from(data).toString('base64')}`; this.onloadend?.(); }); }
};
const mats={};
for(const [name,color,metalness,roughness] of [
  ['bronze','#c98f3a',.65,.48],['goldEdge','#e2b45c',.65,.4],
  ['darkBronze','#785226',.6,.6],['crimson','#9e2b2b',0,.95],
  ['redHighlight','#c74848',0,.95],['leather','#493124',0,.94],
  ['skin','#c89b79',0,.85],['ivory','#e6e2d8',0,.9],
  ['iron','#c2c9d1',.7,.35],['wood','#8a6238',0,.9],['shadow','#191713',0,1],
]) mats[name]=new T.MeshStandardMaterial({name,color,metalness,roughness,flatShading:true});
function group(name,parent,x=0,y=0,z=0){const g=new T.Group();g.name=name;g.position.set(x,y,z);parent?.add(g);return g;}
function mesh(name,geo,mat,parent,x=0,y=0,z=0){const m=new T.Mesh(geo,mats[mat]);m.name=name;m.position.set(x,y,z);parent.add(m);return m;}
function box(name,w,h,d,mat,p,x=0,y=0,z=0){return mesh(name,new T.BoxGeometry(w,h,d),mat,p,x,y,z);}
function poly(name,points,depth,mat,p,x=0,y=0,z=0,bevel=0){
  const s=new T.Shape();points.forEach(([a,b],i)=>i?s.lineTo(a,b):s.moveTo(a,b));s.closePath();
  return mesh(name,new T.ExtrudeGeometry(s,{depth,bevelEnabled:bevel>0,bevelThickness:bevel,bevelSize:bevel,bevelSegments:1,steps:1}),mat,p,x,y,z);
}
function cyl(name,r1,r2,h,mat,p,x=0,y=0,z=0,n=10){return mesh(name,new T.CylinderGeometry(r1,r2,h,n),mat,p,x,y,z);}
function beam(name,a,b,width,depth,mat,p){const start=new T.Vector3(...a),end=new T.Vector3(...b),m=box(name,width,start.distanceTo(end),depth,mat,p);m.position.copy(start.add(end).multiplyScalar(.5));m.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),new T.Vector3(...b).sub(new T.Vector3(...a)).normalize());return m;}

function baseBody(){
 const root=group('Dienekes_Body'); root.userData={prototype:true,forward:'+Z',up:'+Y',rig:'Rigid named pivots; no skin weights or clips'};
 const pelvis=group('Pelvis',root,0,1.04,0);
 box('Tunic',.53,.43,.3,'ivory',pelvis,0,-.03,0);
 const torso=group('Torso',pelvis,0,.21,0);
 poly('Cuirass',[[ -.27,-.2],[.27,-.2],[.34,.29],[.25,.47],[-.25,.47],[-.34,.29]],.32,'bronze',torso,0,0,-.16,.025);
 for(const s of [-1,1]){
  poly('ChestPlate'+s,[[-.12,-.06],[.1,-.06],[.14,.06],[.1,.16],[-.1,.15]],.035,'goldEdge',torso,s*.15,.2,.18,.008);
  box('ShoulderStrap'+s,.115,.16,.39,'darkBronze',torso,s*.24,.44,0);
  cyl('Clasp'+s,.043,.043,.045,'goldEdge',torso,s*.24,.4,.23).rotation.x=Math.PI/2;
 }
 box('Belt',.58,.09,.37,'leather',torso,0,-.18,0);
 box('BeltBuckle',.11,.09,.03,'goldEdge',torso,0,-.18,.2);
 for(let i=0;i<3;i++)box('ArmorSeam'+i,.4-i*.035,.012,.015,'darkBronze',torso,0,.13-i*.085,.197);
 for(let i=-2;i<=2;i++)poly('FrontPteruges'+i,[[-.045,.02],[.045,.02],[.04,-.26],[-.036,-.28]],.035,i%2?'leather':'darkBronze',pelvis,i*.11,-.08,.19,.004);
 for(const s of [-1,1]){
  const thigh=group(s<0?'Hip_L':'Hip_R',pelvis,s*.18,-.15,0);
  cyl('Thigh'+s,.11,.095,.38,'skin',thigh,0,-.19,0,8);
  const shin=group(s<0?'Knee_L':'Knee_R',thigh,0,-.39,0);
  cyl('Shin'+s,.092,.065,.35,'skin',shin,0,-.175,0,8);
  poly('Greave'+s,[[-.085,0],[.085,0],[.07,-.34],[-.065,-.34]],.09,'bronze',shin,0,-.01,.02,.013);
  box('GreaveRidge'+s,.023,.29,.02,'goldEdge',shin,0,-.17,.13);
  box('Sandal'+s,.18,.075,.29,'leather',shin,0,-.435,.055);
  box('Foot'+s,.155,.065,.21,'skin',shin,0,-.39,.06);
  box('SandalStrap'+s,.18,.045,.07,'leather',shin,0,-.365,.09);
  const arm=group(s<0?'Shoulder_L':'Shoulder_R',torso,s*.37,.34,0);
  arm.rotation.z=s*.13;
  cyl('UpperArm'+s,.092,.083,.32,'skin',arm,0,-.16,0,8);
  const forearm=group(s<0?'Elbow_L':'Elbow_R',arm,0,-.33,0);
  cyl('Forearm'+s,.085,.06,.28,'skin',forearm,0,-.14,0,8);
  cyl('Bracer'+s,.09,.072,.17,'leather',forearm,0,-.15,0,8);
  box('BracerTrim'+s,.16,.025,.16,'bronze',forearm,0,-.22,0);
  box('Hand'+s,.115,.14,.13,'skin',forearm,0,-.33,0);
  group(s<0?'ShieldSocket':'SpearSocket',forearm,0,-.31,s<0?.25:.075);
 }
 const head=group('Head',torso,0,.64,0);
 cyl('Neck',.075,.08,.12,'skin',torso,0,.52,0);
 box('Face',.25,.29,.23,'skin',head,0,.01,.01);
 mesh('HelmetCrown',new T.SphereGeometry(.205,10,5,0,Math.PI*2,0,Math.PI/2),'bronze',head,0,.135,0);
 box('HelmetBack',.31,.2,.065,'bronze',head,0,.035,-.135);
 box('EyeRecess',.285,.073,.025,'shadow',head,0,.06,.138);
 box('Brow',.34,.045,.045,'goldEdge',head,0,.108,.14);
 poly('Nasal',[[-.025,.1],[.025,.1],[.017,-.13],[-.018,-.13]],.045,'bronze',head,0,0,.16);
 for(const s of [-1,1])poly('CheekGuard'+s,[[-.06,.025],[.06,.025],[.05,-.2],[-.055,-.16]],.065,'bronze',head,s*.119,-.005,.1,.009);
 box('CrestRail',.45,.055,.08,'darkBronze',head,0,.31,0);
 poly('TransverseCrest',[[-.29,0],[-.265,.125],[-.14,.21],[.14,.21],[.265,.125],[.29,0]],.075,'crimson',head,0,.33,-.035);
 for(let i=-5;i<=5;i++)box('CrestTuft'+i,.018,.085,.081,'redHighlight',head,i*.045,.39+.065*(1-Math.abs(i)/6),0);
 // Folded cape, modeled as a shallow solid with faceted alternating pleats.
 const cape=group('Cape',torso,0,.38,-.23);
 for(let i=0;i<6;i++){
  const x0=-.29+i*.096,x1=x0+.096;
  poly('CapeFold'+i,[[x0,0],[x1,0],[x1*1.38,-.95+(i%2)*.04],[x0*1.38,-.95]],.028,i%2?'crimson':'redHighlight',cape,0,0,-.035*(i%2));
 }
 return root;
}
for(const [n,c] of [['navy','#22305c'],['blue','#3a4d88'],['lacquer','#202f42'],['hair','#743c22']])mats[n]=new T.MeshStandardMaterial({color:c,roughness:.8,flatShading:true});
function body(kind){
 const r=baseBody();r.name=kind+'_Body';
 const remove=[];r.traverse(o=>{if(/^(Cuirass|ChestPlate|ShoulderStrap|Clasp|ArmorSeam|FrontPteruges|Crest|Transverse|Cape|Greave|CheekGuard|EyeRecess|Helmet|Brow|Nasal)/.test(o.name))remove.push(o)});remove.forEach(o=>o.removeFromParent());
 const t=r.getObjectByName('Torso'),h=r.getObjectByName('Head'),p=r.getObjectByName('Pelvis');
 r.getObjectByName('ShieldSocket').name='MainHandSocket';r.getObjectByName('SpearSocket').name='OffHandSocket';
 r.traverse(o=>{if(o.isMesh&&/^(Thigh|Shin|Foot|Sandal)/.test(o.name))o.material=mats.leather;});
 for(const s of [-1,1])box('Eye'+s,.03,.025,.012,'shadow',h,s*.063,.05,.133);
 if(kind==='anne'){
 box('Shirt',.5,.58,.33,'ivory',t,0,.12,0);
 for(const s of [-1,1]){
 box('CoatFront'+s,.18,.64,.06,'navy',t,s*.205,.1,.20);
 box('Lapel'+s,.10,.32,.025,'blue',t,s*.13,.28,.245).rotation.z=s*.18;
 box('CoatTail'+s,.25,.48,.065,'navy',p,s*.16,-.26,-.19).rotation.z=s*.08;
 for(let i=0;i<4;i++)mesh('Button',new T.IcosahedronGeometry(.017,0),'goldEdge',t,s*.20,.30-i*.13,.242);
 for(let i=0;i<4;i++)box('HairLock',.065,.32,.07,'hair',h,s*(.08+i*.035),-.10,-.09);
 const arm=r.getObjectByName(s<0?'Shoulder_L':'Shoulder_R');cyl('Sleeve',.105,.095,.3,'navy',arm,0,-.15,0,8);
 const knee=r.getObjectByName(s<0?'Knee_L':'Knee_R');cyl('Boot',.10,.08,.27,'leather',knee,0,-.29,0,8);
 }
 box('CoatBack',.57,.64,.05,'navy',t,0,.10,-.19);
 box('Sash',.57,.10,.36,'crimson',p,0,0,0);
 beam('Bandolier',[-.26,.43,.26],[.22,-.16,.26],.075,.025,'leather',t);
 box('EyePatch',.085,.067,.023,'shadow',h,-.064,.048,.148);
 const hat=group('Tricorn',h,0,.21,0);
 cyl('HatCrown',.15,.20,.14,'shadow',hat,0,.025,0,10);
 poly('FoldedBrim',[[-.34,0],[-.22,.13],[0,.045],[.22,.13],[.34,0],[0,-.045]],.14,'shadow',hat,0,0,-.03);
 beam('HatTrim',[-.32,.012,.12],[0,-.03,.12],.015,.014,'goldEdge',hat);beam('HatTrim',[0,-.03,.12],[.32,.012,.12],.015,.014,'goldEdge',hat);
 }else{
 r.getObjectByName('Tunic').material=mats.lacquer;
 box('Do',.57,.60,.35,'lacquer',t,0,.12,0);
 for(let i=0;i<7;i++)box('Lacing',.55,.018,.014,'crimson',t,0,.38-i*.075,.185);
 for(const s of [-1,1]){
 const shoulder=r.getObjectByName(s<0?'Shoulder_L':'Shoulder_R');
 for(let i=0;i<4;i++){box('SodePlate',.27,.085,.40,'lacquer',shoulder,s*.035,-i*.075,0);box('SodeLace',.27,.014,.012,'crimson',shoulder,s*.035,-i*.075,.21);}
 const hip=r.getObjectByName(s<0?'Hip_L':'Hip_R');box('Hakama',.27,.39,.31,'lacquer',hip,0,-.17,0);
 for(let i=0;i<4;i++){box('SkirtPlate',.25,.09,.045,'lacquer',p,s*.15,-.1-i*.08,.20);box('SkirtLace',.24,.012,.015,'crimson',p,s*.15,-.1-i*.08,.229);}
 }
 mesh('KabutoBowl',new T.SphereGeometry(.215,12,6,0,Math.PI*2,0,Math.PI/2),'lacquer',h,0,.12,0);
 for(let i=0;i<3;i++)box('NeckGuard',.36+i*.045,.065,.13,'lacquer',h,0,.05-i*.065,-.14);
 box('Mempo',.24,.13,.055,'crimson',h,0,-.075,.145);
 poly('GoldCrest',[[-.23,.22],[-.13,.04],[0,0],[.13,.04],[.23,.22],[.13,.13],[0,.08],[-.13,.13]],.035,'goldEdge',h,0,.26,.11);
 }
 if(kind==='tomoe'){
  const discard=[];r.traverse(o=>{if(/^(Do|Lacing|Sode|Hakama|Skirt|Tunic|Belt|BracerTrim)/.test(o.name))discard.push(o)});discard.forEach(o=>o.removeFromParent());
  // Armor follows a thin articulated figure instead of hiding it in boxes.
  cyl('TaperedDo',.145,.105,.47,'lacquer',t,0,.13,0,10);
  for(let i=0;i<5;i++)cyl('DoLace',.148-i*.008,.148-i*.008,.014,'crimson',t,0,.32-i*.08,0,10);
  cyl('Waist',.10,.095,.16,'lacquer',p,0,0,0,10);
  for(const side of [-1,1]){
   const arm=r.getObjectByName(side<0?'Shoulder_L':'Shoulder_R');arm.position.x=side*.21;arm.rotation.z=side*.30;
   const hip=r.getObjectByName(side<0?'Hip_L':'Hip_R');hip.position.x=side*.12;hip.rotation.z=side*.065;
   mesh('SmallShoulder',new T.SphereGeometry(.115,8,5,0,Math.PI*2,0,Math.PI/2),'lacquer',arm,0,0,0);
   const thigh=r.getObjectByName('Thigh'+side);thigh.scale.set(.58,.90,.58);thigh.material=mats.lacquer;
   const shin=r.getObjectByName('Shin'+side);shin.scale.set(.55,.9,.55);shin.material=mats.lacquer;
   for(const stem of ['UpperArm','Forearm','Bracer']){const o=r.getObjectByName(stem+side);o.scale.set(.52,.86,.52);o.material=mats.lacquer;}
   for(const stem of ['Hand','Foot','Sandal','SandalStrap'])r.getObjectByName(stem+side).scale.set(.68,.75,.70);
   const knee=r.getObjectByName(side<0?'Knee_L':'Knee_R');
   mesh('KneeJoint',new T.SphereGeometry(.056,8,6),'iron',knee);
   const elbow=r.getObjectByName(side<0?'Elbow_L':'Elbow_R');mesh('ElbowJoint',new T.SphereGeometry(.048,8,6),'iron',elbow);
   poly('HipFlap',[[-.045,0],[.045,0],[.065,-.17],[-.035,-.19]],.022,'lacquer',hip,0,0,.082);
  }
  const face=r.getObjectByName('Face');face.geometry.dispose();face.geometry=new T.SphereGeometry(.155,10,8);face.scale.set(.86,1.05,.86);
  h.scale.set(.82,.85,.82);
 }
 return r;
}
function sword(kind){
 const r=group(kind==='anne'?'Anne_Cutlass':'Tomoe_Katana');r.userData={attachment:'MainHandSocket',axis:'+Y',origin:'grip center'};
 cyl('Grip',.03,.03,.22,'leather',r);
 for(let i=0;i<5;i++)cyl('Wrap',.032,.032,.015,kind==='anne'?'goldEdge':'crimson',r,0,-.08+i*.04,0,8);
 cyl('Guard',.09,.09,.025,'goldEdge',r,0,.13,0,12);
 const length=kind==='anne'?.64:.95,width=kind==='anne'?.065:.03;
 poly('Blade',[[-width,0],[width,0],[width+.025,length*.65],[.1,length],[.065,length+.05],[-width+.02,length*.65]],.025,'iron',r,0,.16,-.0125);
 if(kind==='anne'){beam('KnuckleGuard',[.08,.13,0],[.09,-.10,0],.025,.025,'goldEdge',r);beam('GuardReturn',[.09,-.10,0],[0,-.13,0],.025,.025,'goldEdge',r);}
 return r;
}
function pistol(){
 const r=group('Anne_Pistol');r.userData={attachment:'OffHandSocket',forward:'+Y',use:'nonfunctional stylized game prop'};
 box('Stock',.085,.22,.075,'wood',r,0,0,0).rotation.z=-.3;
 box('Forestock',.075,.26,.065,'wood',r,0,.19,0);
 cyl('Barrel',.038,.045,.32,'iron',r,0,.28,.048,8);
 box('Lock',.055,.07,.035,'goldEdge',r,.055,.13,0);return r;
}
function bow(){
 const r=group('Tomoe_Yumi');r.userData={attachment:'MainHandSocket',axis:'+Y',origin:'grip center'};
 const points=[[0,-.62,0],[-.10,-.48,0],[-.13,-.20,0],[0,0,0],[-.16,.40,0],[-.13,.85,0],[0,1.13,0]];
 for(let i=0;i<points.length-1;i++)beam('BowLimb',points[i],points[i+1],.03,.035,'wood',r);
 beam('String',points[0],points.at(-1),.006,.006,'ivory',r);cyl('Grip',.027,.027,.15,'leather',r);return r;
}
function arrow(){const r=group('Tomoe_Arrow');cyl('Shaft',.006,.006,.85,'wood',r,0,.3,0,6);mesh('Tip',new T.ConeGeometry(.025,.10,4),'iron',r,0,.765,0);box('Fletching',.075,.09,.008,'ivory',r,0,-.08,0);return r;}
function saya(){const r=group('Tomoe_Saya');box('Scabbard',.07,1,.055,'lacquer',r,0,.4,0);box('Collar',.075,.04,.06,'goldEdge',r,0,.90,0);return r;}
function fighter(kind){
 const r=body('tomoe');r.name=kind+'_Body';
 const del=[];r.traverse(o=>{if(/^(TaperedDo|DoLace|SmallShoulder|HipFlap|Kabuto|NeckGuard|Mempo|GoldCrest)/.test(o.name))del.push(o)});del.forEach(o=>o.removeFromParent());
 const t=r.getObjectByName('Torso'),h=r.getObjectByName('Head'),p=r.getObjectByName('Pelvis');
 r.getObjectByName('Neck').scale.y=2.6;
 if(kind==='hanzo'){const neck=r.getObjectByName('Neck');neck.material=mats.navy;neck.scale.y=1.15;neck.position.y=.415;h.position.y-=.15;cyl('HoodNeckFabric',.095,.10,.16,'navy',t,0,.415,0,12);}
 for(const side of [-1,1]){r.getObjectByName('Eye'+side).position.z=.151;beam('ShoulderLink',[side*.07,.34,0],[side*.21,.34,0],.07,.07,kind==='nai'?'skin':'navy',t);}
 cyl('FittedTorso',.125,.095,.49,kind==='nai'?'skin':'navy',t,0,.12,0,10);
 r.traverse(o=>{if(!o.isMesh)return;if(/^(UpperArm|Forearm|Thigh|Shin|KneeJoint|ElbowJoint|Waist|Bracer)/.test(o.name))o.material=mats[kind==='nai'?'skin':'navy'];});
 if(kind==='nai'){
 mesh('Hair',new T.SphereGeometry(.16,10,6,0,Math.PI*2,0,Math.PI/2),'shadow',h,0,.035,0);
 mesh('HairKnot',new T.IcosahedronGeometry(.08,1),'shadow',h,0,.10,-.14);
 cyl('ShortsWaist',.112,.12,.15,'crimson',p,0,-.045,0,10);
 for(const side of [-1,1]){
 const hip=r.getObjectByName(side<0?'Hip_L':'Hip_R');
 cyl('ShortsLeg',.087,.092,.19,'crimson',hip,0,-.075,0,8);
 cyl('ShortsTrim',.095,.095,.02,'goldEdge',hip,0,-.17,0,8);
 const arm=r.getObjectByName(side<0?'Shoulder_L':'Shoulder_R');
 cyl('ArmCord',.051,.051,.034,'crimson',arm,0,-.12,0,8);
 const fore=r.getObjectByName(side<0?'Elbow_L':'Elbow_R');
 for(let i=0;i<5;i++)cyl('WristCord',.045,.045,.012,'ivory',fore,0,-.23-i*.024,0,8);
 r.getObjectByName('Hand'+side).material=mats.ivory;
 for(const stem of ['Foot','Sandal'])r.getObjectByName(stem+side).material=mats.skin;
 r.getObjectByName('SandalStrap'+side).visible=false;
 const knee=r.getObjectByName(side<0?'Knee_L':'Knee_R');cyl('AnkleWrap',.048,.048,.065,'crimson',knee,0,-.34,0,8);
 }
 }else{
 const face=r.getObjectByName('Face');face.material=mats.navy;
 box('EyeOpening',.19,.045,.018,'skin',h,0,.05,.135);
 for(const side of [-1,1])r.getObjectByName('Eye'+side).position.z=.151;
 beam('ChestStrapA',[-.11,.36,.115],[.09,-.08,.115],.034,.018,'blue',t);
 beam('ChestStrapB',[.11,.36,.12],[-.09,-.08,.12],.034,.018,'blue',t);
 cyl('Sash',.105,.105,.07,'blue',p);
 box('Pouch',.10,.12,.07,'navy',p,.13,-.07,0);
 for(const side of [-1,1])r.getObjectByName('Hand'+side).material=mats.navy;
 }
 return r;
}
function headband(){const r=group('Nai_Mongkhon');const ring=mesh('Cord',new T.TorusGeometry(.16,.014,6,16),'goldEdge',r,0,.065,0);ring.rotation.x=Math.PI/2;beam('CordTail',[0,.065,-.16],[.02,-.24,-.19],.018,.018,'crimson',r);return r;}
function scarf(){const r=group('Hanzo_Scarf');cyl('NeckWrap',.088,.088,.065,'blue',r);poly('ScarfTail',[[-.04,0],[.04,0],[.09,-.40],[-.015,-.36]],.015,'blue',r,0,0,-.10);return r;}
function tanto(){const r=group('Hanzo_Tanto');r.userData={attachment:'OffHandSocket',axis:'+Y',origin:'grip'};cyl('Grip',.025,.025,.14,'navy',r);box('Guard',.08,.02,.05,'iron',r,0,.09,0);poly('Blade',[[-.025,0],[.025,0],[.025,.24],[0,.32],[-.025,.27]],.018,'iron',r,0,.10,-.009);return r;}
function yari(){const r=group('Hanzo_Yari');r.userData={attachment:'MainHandSocket',axis:'+Y',origin:'grip'};cyl('Shaft',.015,.015,1.8,'wood',r,0,.25,0,8);poly('Blade',[[-.028,0],[.028,0],[.018,.22],[0,.30],[-.018,.22]],.02,'iron',r,0,1.15,-.01);return r;}
function kunai(){const r=group('Hanzo_Kunai');cyl('Grip',.017,.017,.12,'navy',r);poly('Blade',[[0,0],[-.047,.07],[0,.23],[.047,.07]],.016,'iron',r,0,.06,-.008);mesh('Ring',new T.TorusGeometry(.027,.007,5,10),'iron',r,0,-.08,0);return r;}
mats.rust=new T.MeshStandardMaterial({color:'#b2543a',roughness:1,flatShading:true});
mats.deel=new T.MeshStandardMaterial({color:'#426967',roughness:1,flatShading:true});
function nextBody(k){
 const r=fighter('hanzo');r.name=k+'_Body';
 const remove=[];r.traverse(o=>{if(/^(HoodNeckFabric|EyeOpening|ChestStrap|Pouch|Sash)/.test(o.name))remove.push(o)});remove.forEach(o=>o.removeFromParent());
 const h=r.getObjectByName('Head'),t=r.getObjectByName('Torso'),p=r.getObjectByName('Pelvis');
 r.getObjectByName('Face').material=mats.skin;r.getObjectByName('Neck').material=mats.skin;
 r.traverse(o=>{if(o.isMesh&&/^(UpperArm|Forearm|Bracer|FittedTorso|ShoulderLink)/.test(o.name))o.material=mats[k==='subutai'?'deel':'leather'];if(o.isMesh&&/^Hand/.test(o.name))o.material=mats.skin;if(o.isMesh&&/^(Thigh|Shin|Waist)/.test(o.name))o.material=mats.leather;});
 cyl('Belt',.108,.108,.05,'leather',p,0,0,0);
 box('Buckle',.06,.05,.02,'goldEdge',p,0,0,.115);
 if(k==='subutai'){
 for(const side of [-1,1]){const hip=r.getObjectByName(side<0?'Hip_L':'Hip_R');cyl('SplitDeelSkirt',.078,.10,.24,'deel',hip,0,-.10,0,8);}
 beam('DeelTrim',[.08,.36,.12],[-.08,.13,.12],.015,.018,'goldEdge',t);
 beam('DeelOpening',[-.08,.13,.12],[-.08,-.12,.12],.015,.018,'goldEdge',t);
 mesh('Cap',new T.ConeGeometry(.18,.24,10),'deel',h,0,.20,0);
 cyl('FurBand',.18,.18,.055,'leather',h,0,.11,0,12);
 for(const side of [-1,1]){box('CapFlap',.065,.20,.075,'leather',h,side*.14,-.005,-.02);box('Mustache',.065,.018,.018,'shadow',h,side*.032,-.04,.14);}
 }else{
 cyl('HatCrown',.15,.17,.16,'leather',h,0,.19,0,10);
 const brim=cyl('HatBrim',.29,.29,.025,'leather',h,0,.105,0,16);brim.scale.z=.75;
 cyl('HatBand',.172,.172,.035,'shadow',h,0,.14,0,10);
 for(const side of [-1,1])box('Mustache',.063,.022,.023,'shadow',h,side*.035,-.045,.143);
 box('Holster',.075,.18,.06,'leather',p,.14,-.10,0);
 poly('Bandana',[[-.09,0],[.09,0],[0,-.10]],.02,'crimson',t,0,.38,.10);
 }
 return r;
}
function poncho(){const r=group('Wyatt_Poncho');poly('Front',[[-.22,.10],[.22,.10],[.18,-.38],[0,-.46],[-.18,-.38]],.022,'rust',r,0,0,.15);poly('Back',[[-.22,.10],[.22,.10],[.18,-.4],[-.18,-.4]],.022,'rust',r,0,0,-.15);for(let i=0;i<3;i++)box('WovenStripe',.35,.018,.025,'ivory',r,0,-.22-i*.06,.165);return r;}
function shortBow(){const r=group('Subutai_Bow');r.userData={attachment:'MainHandSocket',origin:'grip',axis:'+Y'};const a=[[.035,-.63,0],[-.08,-.48,0],[-.14,-.29,0],[0,0,0],[-.14,.29,0],[-.08,.48,0],[.035,.63,0]];for(let i=0;i<a.length-1;i++)beam('Limb',a[i],a[i+1],.032,.03,'wood',r);beam('String',a[0],a.at(-1),.005,.005,'ivory',r);cyl('Grip',.024,.024,.14,'leather',r);return r;}
function quiver(){const r=group('Subutai_Quiver');cyl('Case',.075,.062,.49,'leather',r);for(let i=0;i<4;i++){cyl('ArrowShaft',.006,.006,.43,'wood',r,(i-1.5)*.026,.22,0,6);box('Feather',.027,.055,.007,'ivory',r,(i-1.5)*.026,.42,0);}return r;}
function revolver(){const r=group('Wyatt_Revolver');r.userData={attachment:'MainHandSocket',forward:'+Y',use:'nonfunctional stylized game prop'};box('Grip',.065,.13,.06,'wood',r,0,-.025,0).rotation.z=-.25;box('Frame',.06,.10,.05,'iron',r,0,.065,0);cyl('Cylinder',.047,.047,.095,'iron',r,0,.11,0,8);cyl('Barrel',.024,.024,.19,'iron',r,0,.23,0,8);return r;}
const exporter=new GLTFExporter();
for(const k of ['subutai','wyatt']){
 await fs.mkdir(k,{recursive:true});const a=nextBody(k);a.name=k+'_Assembled';
 if(k==='subutai'){a.getObjectByName('MainHandSocket').add(shortBow());const q=quiver();q.position.set(.07,.16,-.21);q.rotation.z=-.25;a.getObjectByName('Torso').add(q);}else{a.getObjectByName('MainHandSocket').add(revolver());const p=poncho();p.position.y=.28;a.getObjectByName('Torso').add(p);}
 const knife=tanto();knife.name='Subutai_Knife';
 const parts=k==='subutai'?[['bow',shortBow()],['quiver',quiver()],['knife',knife],['arrow',arrow()]]:[['poncho',poncho()],['revolver',revolver()]];
 for(const [n,o] of [['body',nextBody(k)],...parts,['assembled',a]])await fs.writeFile(k+'/'+k+'-'+n+'.glb',Buffer.from(await exporter.parseAsync(o,{binary:true})));
 const faces=[];a.updateMatrixWorld(true);a.traverse(o=>{if(!o.isMesh||!o.visible)return;const g=o.geometry.index?o.geometry.toNonIndexed():o.geometry,p=g.attributes.position;for(let i=0;i<p.count;i+=3)faces.push({vertices:[0,1,2].map(j=>new T.Vector3().fromBufferAttribute(p,i+j).applyMatrix4(o.matrixWorld).toArray()),color:o.material.color.clone().convertLinearToSRGB().toArray()});});await fs.writeFile(k+'/mesh-preview.json',JSON.stringify(faces));console.log(k+': '+faces.length+' triangles');
}
