Nai Khanom Tom slim stick-fighter prototype. Rigid named pivots, +Y up, +Z forward. No skin weights or animation clips; not integrated into game.
Separate equipment GLBs included; Nai wraps remain named meshes in body. Source requires Three.js; node generate.mjs regenerates both fighters. Stylized game interpretation.
