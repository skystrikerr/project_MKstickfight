import fs from 'node:fs';import assert from 'node:assert/strict';import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
const manifest=JSON.parse(fs.readFileSync('manifest.json'));let count=0;
for(const m of manifest)for(const part of ['body',...m.weapons,'assembled']){
 const b=fs.readFileSync(m.id+'/'+m.id+'-'+part+'.glb');const g=await new GLTFLoader().parseAsync(b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength),'');assert.ok(g.scene.children.length);
 if(part==='body'){for(const w of m.weapons)assert.equal(g.scene.getObjectByName(m.id+'_'+w),undefined);for(const n of ['HipConnector-1','HipConnector1'])assert.ok(g.scene.getObjectByName(n));}
 g.scene.updateMatrixWorld(true);g.scene.traverse(o=>assert.ok(o.matrixWorld.elements.every(Number.isFinite)));count++;
}
console.log(count+' GLBs loaded; 12 weapon-free bodies, hip connectors and finite transforms passed.');
