The Ia Drang Trooper slim stick-fighter prototype. Separate core equipment and assembled GLBs. Rigid named pivots, +Y up, +Z forward. No skin weights or animation clips. Not integrated into game.
Source requires Three.js; node generate.mjs regenerates both fighters. Stylized game interpretation. Equipment is nonfunctional game geometry.

Revision 2: connected both thighs to pelvis with hip connectors and rounded joints. Body excludes weapons. Rifle, knife and bayonet are each separate GLB files; assembled GLB is a convenience preview.
