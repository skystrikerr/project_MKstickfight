DIENEKES — LOW-POLY GAME PROTOTYPE

dienekes-body.glb: character only, including armor, helmet and cloak.
dienekes-shield.glb: separate round shield; pivot at rear grip; front +Z.
dienekes-spear.glb: separate stylized game prop; grip at origin; axis +Y.
dienekes-assembled.glb: complete preview, with equipment still separate nodes.
dienekes-preview.png: offline rendering of actual model geometry.

Based on the game's spartan.ts design: bronze armor, crimson cloak, transverse
helmet crest, lambda shield and dory. This follows the game's art direction;
it is not a claim about Dienekes' historical appearance.

Format: glTF 2.0 binary; +Y up, +Z forward. Flat-color PBR materials, no bitmap
textures. Named rigid joints and ShieldSocket/SpearSocket attachment nodes.
No skin weights, animation clips, collision shapes, LODs or combat integration.
The shield and spear can be replaced independently. Import GLBs into Blender
or Three.js; use the assembled file in the Asset Lab's model bay.

To regenerate: install Node.js and `npm install three`, then run
`node generate.mjs` from this folder. Source is included for further changes.
