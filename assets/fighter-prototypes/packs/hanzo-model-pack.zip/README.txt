Hattori Hanzo slim stick-fighter prototype. Rigid named pivots, +Y up, +Z forward. No skin weights or animation clips; not integrated into game.
Separate equipment GLBs included; Nai wraps remain named meshes in body. Source requires Three.js; node generate.mjs regenerates both fighters. Stylized game interpretation.

Revision 2: full dark fabric neck coverage connecting hood and torso, including beneath the separate scarf.

Revision 3: shortened covered neck and lowered hood and scarf.
