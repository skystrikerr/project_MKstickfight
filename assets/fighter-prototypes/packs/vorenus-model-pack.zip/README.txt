Lucius Vorenus low-poly prototype
Separate body, scutum, spear, and optional gladius GLBs; assembled GLB holds shield and spear to match the current game loadout.
Rigid named pivots, +Y up, +Z forward. No skin weights or animation clips. Not integrated into the live game.
Source: generate.mjs (requires Three.js). Preview is rendered from actual geometry. Stylized game interpretation.
