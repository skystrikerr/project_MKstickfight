import * as T from 'three';
import { GLTFExporter } from 'three/addons/exporters/GLTFExporter.js';
import fs from 'node:fs/promises';

// Node-only adapter for the Three.js exporter. Install `three` to regenerate.
globalThis.FileReader = class {
  readAsArrayBuffer(blob) { blob.arrayBuffer().then(data => { this.result=data; this.onloadend?.(); }); }
  readAsDataURL(blob) { blob.arrayBuffer().then(data => { this.result=`data:${blob.type};base64,${Buffer.from(data).toString('base64')}`; this.onloadend?.(); }); }
};
const mats={};
for(const [name,color,metalness,roughness] of [
  ['bronze','#c98f3a',.65,.48],['goldEdge','#e2b45c',.65,.4],
  ['darkBronze','#785226',.6,.6],['crimson','#9e2b2b',0,.95],
  ['redHighlight','#c74848',0,.95],['leather','#493124',0,.94],
  ['skin','#c89b79',0,.85],['ivory','#e6e2d8',0,.9],
  ['iron','#c2c9d1',.7,.35],['wood','#8a6238',0,.9],['shadow','#191713',0,1],
]) mats[name]=new T.MeshStandardMaterial({name,color,metalness,roughness,flatShading:true});
function group(name,parent,x=0,y=0,z=0){const g=new T.Group();g.name=name;g.position.set(x,y,z);parent?.add(g);return g;}
function mesh(name,geo,mat,parent,x=0,y=0,z=0){const m=new T.Mesh(geo,mats[mat]);m.name=name;m.position.set(x,y,z);parent.add(m);return m;}
function box(name,w,h,d,mat,p,x=0,y=0,z=0){return mesh(name,new T.BoxGeometry(w,h,d),mat,p,x,y,z);}
function poly(name,points,depth,mat,p,x=0,y=0,z=0,bevel=0){
  const s=new T.Shape();points.forEach(([a,b],i)=>i?s.lineTo(a,b):s.moveTo(a,b));s.closePath();
  return mesh(name,new T.ExtrudeGeometry(s,{depth,bevelEnabled:bevel>0,bevelThickness:bevel,bevelSize:bevel,bevelSegments:1,steps:1}),mat,p,x,y,z);
}
function cyl(name,r1,r2,h,mat,p,x=0,y=0,z=0,n=10){return mesh(name,new T.CylinderGeometry(r1,r2,h,n),mat,p,x,y,z);}
function beam(name,a,b,width,depth,mat,p){const start=new T.Vector3(...a),end=new T.Vector3(...b),m=box(name,width,start.distanceTo(end),depth,mat,p);m.position.copy(start.add(end).multiplyScalar(.5));m.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),new T.Vector3(...b).sub(new T.Vector3(...a)).normalize());return m;}

function baseBody(){
 const root=group('Dienekes_Body'); root.userData={prototype:true,forward:'+Z',up:'+Y',rig:'Rigid named pivots; no skin weights or clips'};
 const pelvis=group('Pelvis',root,0,1.04,0);
 box('Tunic',.53,.43,.3,'ivory',pelvis,0,-.03,0);
 const torso=group('Torso',pelvis,0,.21,0);
 poly('Cuirass',[[ -.27,-.2],[.27,-.2],[.34,.29],[.25,.47],[-.25,.47],[-.34,.29]],.32,'bronze',torso,0,0,-.16,.025);
 for(const s of [-1,1]){
  poly('ChestPlate'+s,[[-.12,-.06],[.1,-.06],[.14,.06],[.1,.16],[-.1,.15]],.035,'goldEdge',torso,s*.15,.2,.18,.008);
  box('ShoulderStrap'+s,.115,.16,.39,'darkBronze',torso,s*.24,.44,0);
  cyl('Clasp'+s,.043,.043,.045,'goldEdge',torso,s*.24,.4,.23).rotation.x=Math.PI/2;
 }
 box('Belt',.58,.09,.37,'leather',torso,0,-.18,0);
 box('BeltBuckle',.11,.09,.03,'goldEdge',torso,0,-.18,.2);
 for(let i=0;i<3;i++)box('ArmorSeam'+i,.4-i*.035,.012,.015,'darkBronze',torso,0,.13-i*.085,.197);
 for(let i=-2;i<=2;i++)poly('FrontPteruges'+i,[[-.045,.02],[.045,.02],[.04,-.26],[-.036,-.28]],.035,i%2?'leather':'darkBronze',pelvis,i*.11,-.08,.19,.004);
 for(const s of [-1,1]){
  const thigh=group(s<0?'Hip_L':'Hip_R',pelvis,s*.18,-.15,0);
  cyl('Thigh'+s,.11,.095,.38,'skin',thigh,0,-.19,0,8);
  const shin=group(s<0?'Knee_L':'Knee_R',thigh,0,-.39,0);
  cyl('Shin'+s,.092,.065,.35,'skin',shin,0,-.175,0,8);
  poly('Greave'+s,[[-.085,0],[.085,0],[.07,-.34],[-.065,-.34]],.09,'bronze',shin,0,-.01,.02,.013);
  box('GreaveRidge'+s,.023,.29,.02,'goldEdge',shin,0,-.17,.13);
  box('Sandal'+s,.18,.075,.29,'leather',shin,0,-.435,.055);
  box('Foot'+s,.155,.065,.21,'skin',shin,0,-.39,.06);
  box('SandalStrap'+s,.18,.045,.07,'leather',shin,0,-.365,.09);
  const arm=group(s<0?'Shoulder_L':'Shoulder_R',torso,s*.37,.34,0);
  arm.rotation.z=s*.13;
  cyl('UpperArm'+s,.092,.083,.32,'skin',arm,0,-.16,0,8);
  const forearm=group(s<0?'Elbow_L':'Elbow_R',arm,0,-.33,0);
  cyl('Forearm'+s,.085,.06,.28,'skin',forearm,0,-.14,0,8);
  cyl('Bracer'+s,.09,.072,.17,'leather',forearm,0,-.15,0,8);
  box('BracerTrim'+s,.16,.025,.16,'bronze',forearm,0,-.22,0);
  box('Hand'+s,.115,.14,.13,'skin',forearm,0,-.33,0);
  group(s<0?'ShieldSocket':'SpearSocket',forearm,0,-.31,s<0?.25:.075);
 }
 const head=group('Head',torso,0,.64,0);
 cyl('Neck',.075,.08,.12,'skin',torso,0,.52,0);
 box('Face',.25,.29,.23,'skin',head,0,.01,.01);
 mesh('HelmetCrown',new T.SphereGeometry(.205,10,5,0,Math.PI*2,0,Math.PI/2),'bronze',head,0,.135,0);
 box('HelmetBack',.31,.2,.065,'bronze',head,0,.035,-.135);
 box('EyeRecess',.285,.073,.025,'shadow',head,0,.06,.138);
 box('Brow',.34,.045,.045,'goldEdge',head,0,.108,.14);
 poly('Nasal',[[-.025,.1],[.025,.1],[.017,-.13],[-.018,-.13]],.045,'bronze',head,0,0,.16);
 for(const s of [-1,1])poly('CheekGuard'+s,[[-.06,.025],[.06,.025],[.05,-.2],[-.055,-.16]],.065,'bronze',head,s*.119,-.005,.1,.009);
 box('CrestRail',.45,.055,.08,'darkBronze',head,0,.31,0);
 poly('TransverseCrest',[[-.29,0],[-.265,.125],[-.14,.21],[.14,.21],[.265,.125],[.29,0]],.075,'crimson',head,0,.33,-.035);
 for(let i=-5;i<=5;i++)box('CrestTuft'+i,.018,.085,.081,'redHighlight',head,i*.045,.39+.065*(1-Math.abs(i)/6),0);
 // Folded cape, modeled as a shallow solid with faceted alternating pleats.
 const cape=group('Cape',torso,0,.38,-.23);
 for(let i=0;i<6;i++){
  const x0=-.29+i*.096,x1=x0+.096;
  poly('CapeFold'+i,[[x0,0],[x1,0],[x1*1.38,-.95+(i%2)*.04],[x0*1.38,-.95]],.028,i%2?'crimson':'redHighlight',cape,0,0,-.035*(i%2));
 }
 return root;
}
for(const [n,c] of [['navy','#22305c'],['blue','#3a4d88'],['lacquer','#202f42'],['hair','#743c22']])mats[n]=new T.MeshStandardMaterial({color:c,roughness:.8,flatShading:true});
function body(kind){
 const r=baseBody();r.name=kind+'_Body';
 const remove=[];r.traverse(o=>{if(/^(Cuirass|ChestPlate|ShoulderStrap|Clasp|ArmorSeam|FrontPteruges|Crest|Transverse|Cape|Greave|CheekGuard|EyeRecess|Helmet|Brow|Nasal)/.test(o.name))remove.push(o)});remove.forEach(o=>o.removeFromParent());
 const t=r.getObjectByName('Torso'),h=r.getObjectByName('Head'),p=r.getObjectByName('Pelvis');
 r.getObjectByName('ShieldSocket').name='MainHandSocket';r.getObjectByName('SpearSocket').name='OffHandSocket';
 r.traverse(o=>{if(o.isMesh&&/^(Thigh|Shin|Foot|Sandal)/.test(o.name))o.material=mats.leather;});
 for(const s of [-1,1])box('Eye'+s,.03,.025,.012,'shadow',h,s*.063,.05,.133);
 if(kind==='anne'){
 box('Shirt',.5,.58,.33,'ivory',t,0,.12,0);
 for(const s of [-1,1]){
 box('CoatFront'+s,.18,.64,.06,'navy',t,s*.205,.1,.20);
 box('Lapel'+s,.10,.32,.025,'blue',t,s*.13,.28,.245).rotation.z=s*.18;
 box('CoatTail'+s,.25,.48,.065,'navy',p,s*.16,-.26,-.19).rotation.z=s*.08;
 for(let i=0;i<4;i++)mesh('Button',new T.IcosahedronGeometry(.017,0),'goldEdge',t,s*.20,.30-i*.13,.242);
 for(let i=0;i<4;i++)box('HairLock',.065,.32,.07,'hair',h,s*(.08+i*.035),-.10,-.09);
 const arm=r.getObjectByName(s<0?'Shoulder_L':'Shoulder_R');cyl('Sleeve',.105,.095,.3,'navy',arm,0,-.15,0,8);
 const knee=r.getObjectByName(s<0?'Knee_L':'Knee_R');cyl('Boot',.10,.08,.27,'leather',knee,0,-.29,0,8);
 }
 box('CoatBack',.57,.64,.05,'navy',t,0,.10,-.19);
 box('Sash',.57,.10,.36,'crimson',p,0,0,0);
 beam('Bandolier',[-.26,.43,.26],[.22,-.16,.26],.075,.025,'leather',t);
 box('EyePatch',.085,.067,.023,'shadow',h,-.064,.048,.148);
 const hat=group('Tricorn',h,0,.21,0);
 cyl('HatCrown',.15,.20,.14,'shadow',hat,0,.025,0,10);
 poly('FoldedBrim',[[-.34,0],[-.22,.13],[0,.045],[.22,.13],[.34,0],[0,-.045]],.14,'shadow',hat,0,0,-.03);
 beam('HatTrim',[-.32,.012,.12],[0,-.03,.12],.015,.014,'goldEdge',hat);beam('HatTrim',[0,-.03,.12],[.32,.012,.12],.015,.014,'goldEdge',hat);
 }else{
 r.getObjectByName('Tunic').material=mats.lacquer;
 box('Do',.57,.60,.35,'lacquer',t,0,.12,0);
 for(let i=0;i<7;i++)box('Lacing',.55,.018,.014,'crimson',t,0,.38-i*.075,.185);
 for(const s of [-1,1]){
 const shoulder=r.getObjectByName(s<0?'Shoulder_L':'Shoulder_R');
 for(let i=0;i<4;i++){box('SodePlate',.27,.085,.40,'lacquer',shoulder,s*.035,-i*.075,0);box('SodeLace',.27,.014,.012,'crimson',shoulder,s*.035,-i*.075,.21);}
 const hip=r.getObjectByName(s<0?'Hip_L':'Hip_R');box('Hakama',.27,.39,.31,'lacquer',hip,0,-.17,0);
 for(let i=0;i<4;i++){box('SkirtPlate',.25,.09,.045,'lacquer',p,s*.15,-.1-i*.08,.20);box('SkirtLace',.24,.012,.015,'crimson',p,s*.15,-.1-i*.08,.229);}
 }
 mesh('KabutoBowl',new T.SphereGeometry(.215,12,6,0,Math.PI*2,0,Math.PI/2),'lacquer',h,0,.12,0);
 for(let i=0;i<3;i++)box('NeckGuard',.36+i*.045,.065,.13,'lacquer',h,0,.05-i*.065,-.14);
 box('Mempo',.24,.13,.055,'crimson',h,0,-.075,.145);
 poly('GoldCrest',[[-.23,.22],[-.13,.04],[0,0],[.13,.04],[.23,.22],[.13,.13],[0,.08],[-.13,.13]],.035,'goldEdge',h,0,.26,.11);
 }
 if(kind==='tomoe'){
  const discard=[];r.traverse(o=>{if(/^(Do|Lacing|Sode|Hakama|Skirt|Tunic|Belt|BracerTrim)/.test(o.name))discard.push(o)});discard.forEach(o=>o.removeFromParent());
  // Armor follows a thin articulated figure instead of hiding it in boxes.
  cyl('TaperedDo',.145,.105,.47,'lacquer',t,0,.13,0,10);
  for(let i=0;i<5;i++)cyl('DoLace',.148-i*.008,.148-i*.008,.014,'crimson',t,0,.32-i*.08,0,10);
  cyl('Waist',.10,.095,.16,'lacquer',p,0,0,0,10);
  for(const side of [-1,1]){
   const arm=r.getObjectByName(side<0?'Shoulder_L':'Shoulder_R');arm.position.x=side*.21;arm.rotation.z=side*.30;
   const hip=r.getObjectByName(side<0?'Hip_L':'Hip_R');hip.position.x=side*.12;hip.rotation.z=side*.065;
   mesh('SmallShoulder',new T.SphereGeometry(.115,8,5,0,Math.PI*2,0,Math.PI/2),'lacquer',arm,0,0,0);
   const thigh=r.getObjectByName('Thigh'+side);thigh.scale.set(.58,.90,.58);thigh.material=mats.lacquer;
   const shin=r.getObjectByName('Shin'+side);shin.scale.set(.55,.9,.55);shin.material=mats.lacquer;
   for(const stem of ['UpperArm','Forearm','Bracer']){const o=r.getObjectByName(stem+side);o.scale.set(.52,.86,.52);o.material=mats.lacquer;}
   for(const stem of ['Hand','Foot','Sandal','SandalStrap'])r.getObjectByName(stem+side).scale.set(.68,.75,.70);
   const knee=r.getObjectByName(side<0?'Knee_L':'Knee_R');
   mesh('KneeJoint',new T.SphereGeometry(.056,8,6),'iron',knee);
   const elbow=r.getObjectByName(side<0?'Elbow_L':'Elbow_R');mesh('ElbowJoint',new T.SphereGeometry(.048,8,6),'iron',elbow);
   poly('HipFlap',[[-.045,0],[.045,0],[.065,-.17],[-.035,-.19]],.022,'lacquer',hip,0,0,.082);
  }
  const face=r.getObjectByName('Face');face.geometry.dispose();face.geometry=new T.SphereGeometry(.155,10,8);face.scale.set(.86,1.05,.86);
  h.scale.set(.82,.85,.82);
 }
 return r;
}
function sword(kind){
 const r=group(kind==='anne'?'Anne_Cutlass':'Tomoe_Katana');r.userData={attachment:'MainHandSocket',axis:'+Y',origin:'grip center'};
 cyl('Grip',.03,.03,.22,'leather',r);
 for(let i=0;i<5;i++)cyl('Wrap',.032,.032,.015,kind==='anne'?'goldEdge':'crimson',r,0,-.08+i*.04,0,8);
 cyl('Guard',.09,.09,.025,'goldEdge',r,0,.13,0,12);
 const length=kind==='anne'?.64:.95,width=kind==='anne'?.065:.03;
 poly('Blade',[[-width,0],[width,0],[width+.025,length*.65],[.1,length],[.065,length+.05],[-width+.02,length*.65]],.025,'iron',r,0,.16,-.0125);
 if(kind==='anne'){beam('KnuckleGuard',[.08,.13,0],[.09,-.10,0],.025,.025,'goldEdge',r);beam('GuardReturn',[.09,-.10,0],[0,-.13,0],.025,.025,'goldEdge',r);}
 return r;
}
function pistol(){
 const r=group('Anne_Pistol');r.userData={attachment:'OffHandSocket',forward:'+Y',use:'nonfunctional stylized game prop'};
 box('Stock',.085,.22,.075,'wood',r,0,0,0).rotation.z=-.3;
 box('Forestock',.075,.26,.065,'wood',r,0,.19,0);
 cyl('Barrel',.038,.045,.32,'iron',r,0,.28,.048,8);
 box('Lock',.055,.07,.035,'goldEdge',r,.055,.13,0);return r;
}
function bow(){
 const r=group('Tomoe_Yumi');r.userData={attachment:'MainHandSocket',axis:'+Y',origin:'grip center'};
 const points=[[0,-.62,0],[-.10,-.48,0],[-.13,-.20,0],[0,0,0],[-.16,.40,0],[-.13,.85,0],[0,1.13,0]];
 for(let i=0;i<points.length-1;i++)beam('BowLimb',points[i],points[i+1],.03,.035,'wood',r);
 beam('String',points[0],points.at(-1),.006,.006,'ivory',r);cyl('Grip',.027,.027,.15,'leather',r);return r;
}
function arrow(){const r=group('Tomoe_Arrow');cyl('Shaft',.006,.006,.85,'wood',r,0,.3,0,6);mesh('Tip',new T.ConeGeometry(.025,.10,4),'iron',r,0,.765,0);box('Fletching',.075,.09,.008,'ivory',r,0,-.08,0);return r;}
function saya(){const r=group('Tomoe_Saya');box('Scabbard',.07,1,.055,'lacquer',r,0,.4,0);box('Collar',.075,.04,.06,'goldEdge',r,0,.90,0);return r;}
function fighter(kind){
 const r=body('tomoe');r.name=kind+'_Body';
 const del=[];r.traverse(o=>{if(/^(TaperedDo|DoLace|SmallShoulder|HipFlap|Kabuto|NeckGuard|Mempo|GoldCrest)/.test(o.name))del.push(o)});del.forEach(o=>o.removeFromParent());
 const t=r.getObjectByName('Torso'),h=r.getObjectByName('Head'),p=r.getObjectByName('Pelvis');
 r.getObjectByName('Neck').scale.y=2.6;
 if(kind==='hanzo'){const neck=r.getObjectByName('Neck');neck.material=mats.navy;neck.scale.y=1.15;neck.position.y=.415;h.position.y-=.15;cyl('HoodNeckFabric',.095,.10,.16,'navy',t,0,.415,0,12);}
 for(const side of [-1,1]){r.getObjectByName('Eye'+side).position.z=.151;beam('ShoulderLink',[side*.07,.34,0],[side*.21,.34,0],.07,.07,kind==='nai'?'skin':'navy',t);}
 cyl('FittedTorso',.125,.095,.49,kind==='nai'?'skin':'navy',t,0,.12,0,10);
 r.traverse(o=>{if(!o.isMesh)return;if(/^(UpperArm|Forearm|Thigh|Shin|KneeJoint|ElbowJoint|Waist|Bracer)/.test(o.name))o.material=mats[kind==='nai'?'skin':'navy'];});
 if(kind==='nai'){
 mesh('Hair',new T.SphereGeometry(.16,10,6,0,Math.PI*2,0,Math.PI/2),'shadow',h,0,.035,0);
 mesh('HairKnot',new T.IcosahedronGeometry(.08,1),'shadow',h,0,.10,-.14);
 cyl('ShortsWaist',.112,.12,.15,'crimson',p,0,-.045,0,10);
 for(const side of [-1,1]){
 const hip=r.getObjectByName(side<0?'Hip_L':'Hip_R');
 cyl('ShortsLeg',.087,.092,.19,'crimson',hip,0,-.075,0,8);
 cyl('ShortsTrim',.095,.095,.02,'goldEdge',hip,0,-.17,0,8);
 const arm=r.getObjectByName(side<0?'Shoulder_L':'Shoulder_R');
 cyl('ArmCord',.051,.051,.034,'crimson',arm,0,-.12,0,8);
 const fore=r.getObjectByName(side<0?'Elbow_L':'Elbow_R');
 for(let i=0;i<5;i++)cyl('WristCord',.045,.045,.012,'ivory',fore,0,-.23-i*.024,0,8);
 r.getObjectByName('Hand'+side).material=mats.ivory;
 for(const stem of ['Foot','Sandal'])r.getObjectByName(stem+side).material=mats.skin;
 r.getObjectByName('SandalStrap'+side).visible=false;
 const knee=r.getObjectByName(side<0?'Knee_L':'Knee_R');cyl('AnkleWrap',.048,.048,.065,'crimson',knee,0,-.34,0,8);
 }
 }else{
 const face=r.getObjectByName('Face');face.material=mats.navy;
 box('EyeOpening',.19,.045,.018,'skin',h,0,.05,.135);
 for(const side of [-1,1])r.getObjectByName('Eye'+side).position.z=.151;
 beam('ChestStrapA',[-.11,.36,.115],[.09,-.08,.115],.034,.018,'blue',t);
 beam('ChestStrapB',[.11,.36,.12],[-.09,-.08,.12],.034,.018,'blue',t);
 cyl('Sash',.105,.105,.07,'blue',p);
 box('Pouch',.10,.12,.07,'navy',p,.13,-.07,0);
 for(const side of [-1,1])r.getObjectByName('Hand'+side).material=mats.navy;
 }
 return r;
}
function headband(){const r=group('Nai_Mongkhon');const ring=mesh('Cord',new T.TorusGeometry(.16,.014,6,16),'goldEdge',r,0,.065,0);ring.rotation.x=Math.PI/2;beam('CordTail',[0,.065,-.16],[.02,-.24,-.19],.018,.018,'crimson',r);return r;}
function scarf(){const r=group('Hanzo_Scarf');cyl('NeckWrap',.088,.088,.065,'blue',r);poly('ScarfTail',[[-.04,0],[.04,0],[.09,-.40],[-.015,-.36]],.015,'blue',r,0,0,-.10);return r;}
function tanto(){const r=group('Hanzo_Tanto');r.userData={attachment:'OffHandSocket',axis:'+Y',origin:'grip'};cyl('Grip',.025,.025,.14,'navy',r);box('Guard',.08,.02,.05,'iron',r,0,.09,0);poly('Blade',[[-.025,0],[.025,0],[.025,.24],[0,.32],[-.025,.27]],.018,'iron',r,0,.10,-.009);return r;}
function yari(){const r=group('Hanzo_Yari');r.userData={attachment:'MainHandSocket',axis:'+Y',origin:'grip'};cyl('Shaft',.015,.015,1.8,'wood',r,0,.25,0,8);poly('Blade',[[-.028,0],[.028,0],[.018,.22],[0,.30],[-.018,.22]],.02,'iron',r,0,1.15,-.01);return r;}
function kunai(){const r=group('Hanzo_Kunai');cyl('Grip',.017,.017,.12,'navy',r);poly('Blade',[[0,0],[-.047,.07],[0,.23],[.047,.07]],.016,'iron',r,0,.06,-.008);mesh('Ring',new T.TorusGeometry(.027,.007,5,10),'iron',r,0,-.08,0);return r;}
for(const [n,c] of [['olive','#4f5d3a'],['khaki','#8d8560'],['gunmetal','#3f454b']])mats[n]=new T.MeshStandardMaterial({color:c,roughness:.85,flatShading:true});
function newBody(k){
 const r=fighter('hanzo');r.name=k+'_Body';
 const rem=[];r.traverse(o=>{if(/^(HoodNeckFabric|EyeOpening|ChestStrap|Pouch|Sash)/.test(o.name))rem.push(o)});rem.forEach(o=>o.removeFromParent());
 const t=r.getObjectByName('Torso'),h=r.getObjectByName('Head'),p=r.getObjectByName('Pelvis');
 r.getObjectByName('Face').material=mats.skin;r.getObjectByName('Neck').material=mats[k==='trooper'?'skin':'iron'];
 r.traverse(o=>{if(o.isMesh&&/^(UpperArm|Forearm|Bracer|FittedTorso|ShoulderLink|Thigh|Shin|Waist|KneeJoint|ElbowJoint)/.test(o.name))o.material=mats[k==='trooper'?'olive':'iron'];if(o.isMesh&&/^Hand/.test(o.name))o.material=mats[k==='trooper'?'skin':'iron'];});
 if(k==='trooper'){
 for(const side of [-1,1]){
  const hip=r.getObjectByName(side<0?'Hip_L':'Hip_R');
  beam('HipConnector'+side,[side*.045,-.045,0],hip.position.toArray(),.095,.095,'olive',p);
  mesh('HipJoint'+side,new T.SphereGeometry(.068,10,8),'olive',hip,0,-.015,0);
 }
 mesh('Helmet',new T.SphereGeometry(.19,12,6,0,Math.PI*2,0,Math.PI/2),'olive',h,0,.07,0);
 cyl('HelmetRim',.193,.193,.023,'olive',h,0,.07,0,12);
 for(const side of [-1,1]){beam('Webbing',[side*.095,.36,.13],[side*.075,-.10,.13],.026,.025,'khaki',t);box('AmmoPouch',.067,.11,.045,'khaki',p,side*.10,-.02,.09);}
 cyl('Belt',.11,.11,.045,'khaki',p);
 box('VestPocket',.08,.09,.026,'khaki',t,.055,.18,.128);
 }else{
 const face=r.getObjectByName('Face');face.material=mats.iron;
 for(const side of [-1,1])r.getObjectByName('Eye'+side).visible=false;
 cyl('Bascinet',.12,.155,.22,'iron',h,0,.04,0,10);
 mesh('HelmetDome',new T.SphereGeometry(.15,10,5,0,Math.PI*2,0,Math.PI/2),'iron',h,0,.15,0);
 box('VisorSlit',.205,.022,.015,'shadow',h,0,.09,.149);
 poly('VisorPoint',[[-.11,.07],[.11,.07],[.065,-.10],[0,-.14],[-.065,-.10]],.035,'iron',h,0,0,.132);
 for(const side of [-1,1]){const shoulder=r.getObjectByName(side<0?'Shoulder_L':'Shoulder_R');mesh('Pauldron',new T.SphereGeometry(.085,8,5,0,Math.PI*2,0,Math.PI/2),'iron',shoulder);}
 for(let i=0;i<3;i++)cyl('WaistPlate',.111+i*.007,.117+i*.007,.045,'iron',p,0,-.035-i*.04,0,10);
 }
 return r;
}
function rifle(){const r=group('Trooper_Rifle');r.userData={attachment:'OffHandSocket',axis:'+Y',origin:'grip',use:'nonfunctional low-poly game prop'};
 box('Stock',.085,.22,.07,'gunmetal',r,0,-.20,0);box('Receiver',.065,.24,.055,'gunmetal',r,0,.015,0);cyl('Handguard',.037,.03,.25,'gunmetal',r,0,.26,0,8);cyl('Barrel',.011,.011,.24,'gunmetal',r,0,.50,0,6);box('Magazine',.042,.12,.045,'gunmetal',r,.055,-.015,0).rotation.z=.18;box('CarryHandle',.025,.12,.02,'gunmetal',r,-.055,.04,0);return r;}
function longsword(){const r=group('Chandos_Sword');r.userData={attachment:'MainHandSocket',axis:'+Y',origin:'grip'};cyl('Grip',.022,.022,.22,'leather',r);box('Crossguard',.28,.025,.035,'iron',r,0,.13,0);mesh('Pommel',new T.IcosahedronGeometry(.04,0),'iron',r,0,-.14,0);poly('Blade',[[-.031,0],[.031,0],[.024,.72],[0,.85],[-.024,.72]],.025,'iron',r,0,.15,-.0125);return r;}
function heater(){const r=group('Chandos_Shield');r.userData={attachment:'OffHandSocket',forward:'+Z',origin:'rear grip'};poly('Rim',[[-.25,.34],[.25,.34],[.24,-.05],[.16,-.27],[0,-.43],[-.16,-.27],[-.24,-.05]],.04,'iron',r);poly('GoldField',[[-.225,.315],[.225,.315],[.215,-.04],[.14,-.25],[0,-.395],[-.14,-.25],[-.215,-.04]],.008,'goldEdge',r,0,0,.043);poly('RedPile',[[-.15,.315],[.15,.315],[0,-.38]],.009,'crimson',r,0,0,.053);box('BlueRibbon',.45,.055,.014,'blue',r,0,.245,.065);box('Grip',.15,.035,.05,'leather',r,0,0,-.04);return r;}
function surcoat(){const r=group('Chandos_Surcoat');poly('Cloth',[[-.12,.10],[.12,.10],[.10,-.46],[-.10,-.46]],.018,'goldEdge',r,0,0,.145);poly('Pile',[[-.09,.09],[.09,.09],[0,-.38]],.01,'crimson',r,0,0,.166);return r;}
for(const [n,c] of [['ochre','#c99743'],['orange','#ca6829'],['brownskin','#744b32'],['tanskin','#ab7952']])mats[n]=new T.MeshStandardMaterial({color:c,roughness:1,flatShading:true});
function buildFighter(k){
 const r=newBody('trooper');r.name=k+'_Body';
 const rem=[];r.traverse(o=>{if(/^(Helmet|Webbing|AmmoPouch|VestPocket|Belt)/.test(o.name))rem.push(o)});rem.forEach(o=>o.removeFromParent());
 const t=r.getObjectByName('Torso'),h=r.getObjectByName('Head'),p=r.getObjectByName('Pelvis');
 const skin=k==='mgobozi'?'brownskin':'tanskin',cloth=k==='yuekong'?'orange':k==='tzilacatzin'?'ochre':skin;
 r.traverse(o=>{if(!o.isMesh)return;
 if(/^(Face|Neck|Hand|UpperArm|Forearm|Bracer|KneeJoint|ElbowJoint|ShoulderLink)/.test(o.name))o.material=mats[skin];
 if(/^(FittedTorso|Waist|HipConnector|HipJoint|Thigh|Shin)/.test(o.name))o.material=mats[cloth];
 });
 cyl('WaistSash',.112,.112,.06,k==='yuekong'?'crimson':'leather',p);
 if(k==='tzilacatzin'){
 const hat=mesh('JaguarCrown',new T.SphereGeometry(.19,12,6,0,Math.PI*2,0,Math.PI/2),'ochre',h,0,.07,0);
 for(const side of [-1,1]){
 mesh('JaguarEar',new T.IcosahedronGeometry(.055,1),'ochre',h,side*.14,.22,0);
 box('SnoutSide',.065,.055,.09,'ochre',h,side*.095,.095,.12);
 for(let i=0;i<4;i++)mesh('PeltSpot',new T.IcosahedronGeometry(.021,0),'shadow',h,side*(.07+.025*(i%2)),.15+i*.014,.13-i*.025);
 }
 for(let i=0;i<6;i++)cyl('QuiltRow',.126-i*.004,.126-i*.004,.011,'leather',t,0,.32-i*.075,0,10);
 poly('LoinPanel',[[-.065,0],[.065,0],[.045,-.28],[-.045,-.28]],.022,'crimson',p,0,-.04,.11);
 }else if(k==='mgobozi'){
 cyl('HeadRing',.138,.138,.028,'leather',h,0,.10,0,12);
 mesh('Hair',new T.SphereGeometry(.14,10,5,0,Math.PI*2,0,Math.PI/2),'shadow',h,0,.10,0);
 for(const side of [-1,1]){
 const shoulder=r.getObjectByName(side<0?'Shoulder_L':'Shoulder_R');
 for(let i=0;i<3;i++)mesh('ShoulderTuft',new T.IcosahedronGeometry(.055,0),'ivory',shoulder,side*.035,-i*.055,0);
 const hip=r.getObjectByName(side<0?'Hip_L':'Hip_R');cyl('WaistKilt',.075,.09,.16,'leather',hip,0,-.04,0,8);
 }
 poly('FrontApron',[[-.065,0],[.065,0],[.075,-.23],[-.075,-.23]],.02,'ivory',p,0,-.03,.11);
 }else{
 beam('RobeFold',[-.13,.37,.12],[.09,-.09,.12],.075,.025,'crimson',t);
 for(const side of [-1,1]){
 const hip=r.getObjectByName(side<0?'Hip_L':'Hip_R');cyl('RobeLeg',.067,.075,.26,'orange',hip,0,-.11,0,8);
 const knee=r.getObjectByName(side<0?'Knee_L':'Knee_R');for(let i=0;i<4;i++)cyl('LegWrap',.044,.044,.015,'ivory',knee,0,-.19-i*.035,0,8);
 }
 for(let i=0;i<9;i++){const a=i*Math.PI/8;mesh('PrayerBead',new T.IcosahedronGeometry(.018,1),'wood',t,Math.cos(a)*.105,.32-Math.sin(a)*.10,.12);}
 }return r;
}
function club(){const r=group('Tzilacatzin_Macuahuitl');r.userData={attachment:'MainHandSocket',axis:'+Y',origin:'grip',use:'stylized game prop'};
 cyl('Grip',.025,.025,.21,'leather',r);box('WoodBody',.11,.59,.042,'wood',r,0,.42,0);
 for(const side of [-1,1])for(let i=0;i<6;i++)box('ObsidianInset',.042,.065,.032,'shadow',r,side*.066,.18+i*.085,0);return r;}
function iklwa(){const r=group('Mgobozi_Iklwa');r.userData={attachment:'MainHandSocket',axis:'+Y',origin:'grip'};cyl('Haft',.018,.018,.72,'wood',r,0,.08,0,8);poly('Blade',[[0,0],[-.055,.12],[0,.39],[.055,.12]],.02,'iron',r,0,.44,-.01);return r;}
function hideShield(){const r=group('Mgobozi_Isihlangu');r.userData={attachment:'OffHandSocket',forward:'+Z',origin:'rear grip'};
 const shell=mesh('Hide',new T.SphereGeometry(1,16,10),'ivory',r);shell.scale.set(.235,.58,.035);
 for(let i=0;i<7;i++)box('Lacing',.07,.019,.016,'leather',r,0,-.30+i*.10,.04);
 for(const side of [-1,1]){const patch=mesh('HidePatch',new T.CircleGeometry(.11,8),'leather',r,side*.10,side*.18,.035);patch.scale.y=1.5;}
 beam('Spine',[0,-.66,-.035],[0,.66,-.035],.025,.025,'wood',r);return r;}
function staff(){const r=group('Yuekong_Staff');r.userData={attachment:'MainHandSocket',axis:'+Y',origin:'grip'};cyl('WoodStaff',.022,.022,1.85,'wood',r,0,0,0,10);for(const side of [-1,1])cyl('EndBand',.024,.024,.06,'iron',r,0,side*.89,0,10);return r;}
const exporter=new GLTFExporter();
for(const k of ['tzilacatzin','mgobozi','yuekong']){
 await fs.mkdir(k,{recursive:true});const a=buildFighter(k);a.name=k+'_Assembled';
 const parts=k==='tzilacatzin'?[['macuahuitl',club()]]:k==='mgobozi'?[['iklwa',iklwa()],['shield',hideShield()]]:[['staff',staff()]];
 a.getObjectByName('MainHandSocket').add(parts[0][1].clone());
 if(k==='mgobozi')a.getObjectByName('OffHandSocket').add(hideShield());
 for(const [n,o] of [['body',buildFighter(k)],...parts,['assembled',a]])await fs.writeFile(k+'/'+k+'-'+n+'.glb',Buffer.from(await exporter.parseAsync(o,{binary:true})));
 const faces=[];a.updateMatrixWorld(true);a.traverse(o=>{if(!o.isMesh||!o.visible)return;const g=o.geometry.index?o.geometry.toNonIndexed():o.geometry,p=g.attributes.position;for(let i=0;i<p.count;i+=3)faces.push({vertices:[0,1,2].map(j=>new T.Vector3().fromBufferAttribute(p,i+j).applyMatrix4(o.matrixWorld).toArray()),color:o.material.color.clone().convertLinearToSRGB().toArray()});});await fs.writeFile(k+'/mesh-preview.json',JSON.stringify(faces));console.log(k+': '+faces.length+' triangles');
}
