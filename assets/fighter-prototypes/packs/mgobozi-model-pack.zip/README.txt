Mgobozi ovela Ntla slim stick-fighter prototype. Connected hip joints; separate weapon GLBs and weapon-free body. Rigid named pivots, +Y up, +Z forward. No skin weights or animation clips; not integrated into game.
Source requires Three.js; node generate.mjs regenerates all three. Stylized game interpretation with flat-color materials.
