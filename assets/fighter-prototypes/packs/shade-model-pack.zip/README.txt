Kuro - core-loadout prototype
Separate weapon-free body, equipment GLBs, assembled preview. Rigid named joints, +Y up and +Z forward. No skinning, animation clips, or texture maps. Not integrated into game.
Equipment: kunaiF, kunaiB, shuriken, hook
Core visual interpretation; mounts, animals, vehicles and special-move effects are excluded.
Source generate.mjs requires Three.js and regenerates these 12 fighters.
