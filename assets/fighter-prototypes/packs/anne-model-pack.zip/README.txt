Anne Bonny low-poly prototype. Separate equipment GLBs and assembled preview included.
Rigid named joints, +Y up, +Z forward. No skin weights or animation clips. Not integrated into the game.
Source generate.mjs requires Three.js and regenerates both fighters. Stylized game interpretation.
Anne pack covers core cutlass/pistol loadout; special-move cannon and hook are not included. Tomoe includes katana, yumi, arrow and saya.
